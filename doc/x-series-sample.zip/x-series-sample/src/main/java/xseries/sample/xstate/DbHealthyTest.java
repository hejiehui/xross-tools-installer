package xseries.sample.xstate;

import com.xross.tools.xstate.Event;
import com.xross.tools.xstate.StateMachine;
import com.xross.tools.xstate.StateMachineFactory;

public class DbHealthyTest {
	public static void main(String[] args) {
		try {
			StateMachineFactory f = StateMachineFactory.load("new_state_machine.xstate");
			StateMachine sm = f.create("DB Healthy");
			
			System.out.println("Start state: " + sm.getCurrentState().getId());
			notify(sm, "initialize");
			
			notify(sm, "markdown");
			
			notify(sm, "markup");
			
			notify(sm, "shutdown");
			
			System.out.println("End state: " + sm.getCurrentState().getId());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	static void notify(StateMachine sm, String eventId) {
		sm.notify(new Event(eventId));
		System.out.println();
	}
}
