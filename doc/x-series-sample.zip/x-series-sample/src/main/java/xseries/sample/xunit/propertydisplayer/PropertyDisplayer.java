package xseries.sample.xunit.propertydisplayer;

import java.util.Map;

import com.xross.tools.xunit.ApplicationPropertiesAware;
import com.xross.tools.xunit.Context;
import com.xross.tools.xunit.Processor;
import com.xross.tools.xunit.UnitPropertiesAware;

public class PropertyDisplayer implements Processor, ApplicationPropertiesAware, UnitPropertiesAware {
	private Map<String, String> appProps;
	private Map<String, String> unitProps;
	
	@Override
	public void process(Context arg0) {
		System.out.println("App properties");
		for(String key: appProps.keySet())
			System.out.println(String.format("Key: %s Value: %s", key, appProps.get(key)));
		
		System.out.println("\nUnit properties");
		for(String key: unitProps.keySet())
			System.out.println(String.format("Key: %s Value: %s", key, unitProps.get(key)));
	}

	@Override
	public void setUnitProperties(Map<String, String> arg0) {
		appProps = arg0;
	}

	@Override
	public void setApplicationProperties(Map<String, String> arg0) {
		unitProps = arg0;
	}

}
