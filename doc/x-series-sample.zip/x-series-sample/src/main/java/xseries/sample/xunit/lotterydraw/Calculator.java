package xseries.sample.xunit.lotterydraw;

import java.util.Map;

import com.xross.tools.xunit.Context;
import com.xross.tools.xunit.Converter;
import com.xross.tools.xunit.UnitPropertiesAware;

public class Calculator implements Converter, UnitPropertiesAware {
	private double delta;
	private String operation;
	
	@Override
	public Context convert(Context contxt) {
		LotteryDrawContext ctx = (LotteryDrawContext)contxt;
		
		double value = ctx.quantity;
		switch(operation){
			case "+": value+=delta; break;
			case "-": value-=delta; break;
			case "*": value*=delta; break;
			case "/": value/=delta; break;
		}
		
		System.out.println(String.format("%g %s %g = %g", ctx.quantity, operation, delta, value));
		ctx.quantity = value;
		
		return ctx;
	}

	@Override
	public void setUnitProperties(Map<String, String> arg0) {
		delta = Double.parseDouble(arg0.get("delta"));
		operation = arg0.get("operation");
	}
}
