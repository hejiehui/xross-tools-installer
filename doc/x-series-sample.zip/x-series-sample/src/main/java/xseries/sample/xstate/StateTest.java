package xseries.sample.xstate;

import com.xross.tools.xstate.Event;
import com.xross.tools.xstate.StateMachine;
import com.xross.tools.xstate.StateMachineFactory;

public class StateTest {
	public static void main(String[] args) {
		try {
			StateMachineFactory f = StateMachineFactory.load("new_state_machine.xstate");
			StateMachine sm = f.create("Statemachine1ww");
			
			print(sm);
			sm.notify(new Event("e1"));
			
			print(sm);
			sm.notify(new Event("e2"));
			
			print(sm);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	static void print(StateMachine sm) {
		System.out.println("Current state Id: " + sm.getCurrentState().getId());
		System.out.println("Is ended: " + sm.isEnded());
	}
}
