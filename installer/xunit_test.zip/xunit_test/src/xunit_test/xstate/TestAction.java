package xunit_test.xstate;

import com.xross.tools.xstate.EntryAction;
import com.xross.tools.xstate.Event;
import com.xross.tools.xstate.ExitAction;
import com.xross.tools.xstate.TransitAction;
import com.xross.tools.xstate.TransitionGuard;

public class TestAction implements EntryAction, ExitAction, TransitAction, TransitionGuard {
	public void transit(String sourceStateId,String targetStateId, Event event) {
		System.out.println(String.format("Transit from %s to %s on %s", sourceStateId, targetStateId, event.getId()));
	}

	public void exit(String sourceStateId, Event event) {
		System.out.println(String.format("Exit from %s on %s", sourceStateId, event.getId()));
	}

	public void enter(String targetStateId, Event event) {
		System.out.println(String.format("Enter into %s on %s", targetStateId, event.getId()));
	}

	public boolean isTransitAllowed(String sourceId, String targetId, Event event) {return true;}

}
