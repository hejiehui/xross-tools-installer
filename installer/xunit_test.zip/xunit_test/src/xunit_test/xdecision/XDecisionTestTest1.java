package xunit_test.xdecision;

import static org.junit.Assert.*;

import org.junit.Test;

public class XDecisionTestTest1 {

	@Test
	public void testTestGetDecision() {
		fail("Not yet implemented");
	}

}
