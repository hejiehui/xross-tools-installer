package xunit_test.xunit;

import java.util.Map;

import com.xross.tools.xunit.Context;
import com.xross.tools.xunit.Processor;
import com.xross.tools.xunit.UnitPropertiesAware;

public class FieldDisplayer implements Processor, UnitPropertiesAware {
	private String[] fields;
	
	@Override
	public void process(Context arg0) {
		Class<?> clazz = arg0.getClass();
		for(String fieldName: fields) {
			fieldName = fieldName.trim();
			try {
				System.out.println(String.format("%s: %s", fieldName, clazz.getField(fieldName).get(arg0).toString()));
			} catch (Throwable e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void setUnitProperties(Map<String, String> arg0) {
		fields = arg0.get("Fields").split(",");
	}
}
