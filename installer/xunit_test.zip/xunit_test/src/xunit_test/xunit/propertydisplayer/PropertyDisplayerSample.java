package xunit_test.xunit.propertydisplayer;

import xunit_test.xunit.MapContext;

import com.xross.tools.xunit.Processor;
import com.xross.tools.xunit.XunitFactory;

public class PropertyDisplayerSample {
	public static void main(String[] args) {
		try {
			XunitFactory f = XunitFactory.load("model/new_xross_unit.xunit");

			Processor p = f.getProcessor("Display Properties");

			MapContext ctx = new MapContext();
			p.process(ctx);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
