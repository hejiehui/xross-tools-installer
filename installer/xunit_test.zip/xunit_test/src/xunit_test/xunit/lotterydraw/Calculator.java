package xunit_test.xunit.lotterydraw;

import java.util.Map;

import com.xross.tools.xunit.Context;
import com.xross.tools.xunit.Converter;
import com.xross.tools.xunit.UnitPropertiesAware;

public class Calculator implements Converter, UnitPropertiesAware {
	private double delta;
	private String operation;
	
	@Override
	public Context convert(Context arg0) {
		LotteryDrawContext ctx = (LotteryDrawContext)arg0;
		
		double value = ctx.quantity;
		
		switch(operation){
			case "+": value+=delta; break;
			case "-": value-=delta; break;
			case "*": value*=delta; break;
			case "/": value/=delta; break;
		}
		
		ctx.quantity = value;
		
		return ctx;
	}

	@Override
	public void setUnitProperties(Map<String, String> arg0) {
		delta = Double.parseDouble(arg0.get("delta"));
		operation = arg0.get("operation");
	}
}
