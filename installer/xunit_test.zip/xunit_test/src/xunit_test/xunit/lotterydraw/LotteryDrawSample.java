package xunit_test.xunit.lotterydraw;

import com.xross.tools.xunit.Processor;
import com.xross.tools.xunit.XunitFactory;

public class LotteryDrawSample {
	public static void main(String[] args) {
		try {
			XunitFactory f = XunitFactory.load("model/new_xross_unit.xunit");

			Processor p = f.getProcessor("Lottery Draw");

			LotteryDrawContext ctx = new LotteryDrawContext("Jerry", 100, "+");
			p.process(ctx);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
