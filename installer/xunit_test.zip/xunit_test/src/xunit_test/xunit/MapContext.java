package xunit_test.xunit;

import java.util.HashMap;
import java.util.Map;

import com.xross.tools.xunit.Context;

public class MapContext implements Context {
	public Map<String, Object> contents = new HashMap<String, Object>();
}
