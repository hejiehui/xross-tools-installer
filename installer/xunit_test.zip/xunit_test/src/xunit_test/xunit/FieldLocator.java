package xunit_test.xunit;

import java.lang.reflect.Field;
import java.util.Map;

import com.xross.tools.xunit.Context;
import com.xross.tools.xunit.Locator;
import com.xross.tools.xunit.UnitPropertiesAware;

public class FieldLocator implements Locator, UnitPropertiesAware {
	private String defaultKey;
	private String fieldName;
	private Field field;
	
	@Override
	public String getDefaultKey() {
		return null;
	}

	@Override
	public String locate(Context arg0) {
		try {
			Field[] a = arg0.getClass().getFields();
			field = arg0.getClass().getField(fieldName);
			return field.get(arg0).toString();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		return defaultKey;
	}

	@Override
	public void setDefaultKey(String arg0) {
	}

	@Override
	public void setUnitProperties(Map<String, String> arg0) {
		fieldName = arg0.get("field");
	}

}
