package com.xross.sample.xunit.decorators;

import com.xross.tools.xunit.Adapter;
import com.xross.tools.xunit.Context;
import com.xross.tools.xunit.Converter;
import com.xross.tools.xunit.Processor;
import com.xross.tools.xunit.Unit;

public class ConverterAdapter implements Adapter, Processor{
	Converter converter;
	@Override
	public void process(Context ctx) {
		ctx = converter.convert(ctx);
	}

	@Override
	public void setUnit(Unit unit) {
		converter = (Converter)unit;
	}

}
