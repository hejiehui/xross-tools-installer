package com.xross.sample.xunit.validators;

import com.xross.sample.xunit.contexts.IntContext;
import com.xross.tools.xunit.Context;
import com.xross.tools.xunit.Validator;

public class DelayMoreThan200Validator implements Validator {

	@Override
	public boolean validate(Context ctx) {
		return ((IntContext)ctx).delay > 200;
	}

}
