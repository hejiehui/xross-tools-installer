package com.xross.sample.xunit.contexts;

import com.xross.tools.xunit.Context;

public class IntContext implements Context {
	public int delay;
}
