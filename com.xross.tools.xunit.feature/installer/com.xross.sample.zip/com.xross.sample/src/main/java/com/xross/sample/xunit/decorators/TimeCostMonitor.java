package com.xross.sample.xunit.decorators;

import com.xross.tools.xunit.Context;
import com.xross.tools.xunit.impl.DecoratorAdapter;

public class TimeCostMonitor extends DecoratorAdapter {
	private long start;

	public void before(Context ctx) {
		start = System.currentTimeMillis();
		System.out.println("Start monitoring");
	}

	@Override
	public void after(Context ctx) {
		start = System.currentTimeMillis() - start;
		System.out.println("End monitoring, time cost: " + start/1000);
	}

}
