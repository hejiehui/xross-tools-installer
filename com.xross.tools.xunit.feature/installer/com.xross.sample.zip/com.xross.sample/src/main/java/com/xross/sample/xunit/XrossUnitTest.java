package com.xross.sample.xunit;

import junit.framework.TestCase;

import com.xross.sample.xunit.contexts.IntContext;
import com.xross.sample.xunit.contexts.NumberContext;
import com.xross.sample.xunit.contexts.TextContext;
import com.xross.tools.xunit.Converter;
import com.xross.tools.xunit.Processor;
import com.xross.tools.xunit.XrossFactory;

public class XrossUnitTest extends TestCase {
	private XrossFactory factory = XrossFactory.createFromXML("src/main/resources/xross_unit_test.xunit");
	
	public void testProcessor(){
		Processor p;
		try {
			p = factory.getProcessor("processor");
			IntContext ctx = new IntContext();
			ctx.delay = 123;
			p.process(ctx);
			assertEquals(123 - 100, ctx.delay);
		} catch (Exception e) {
			fail();
		}
	}
	
	public void testConverter(){
		Converter c;
		try {
			c = factory.getConverter("converter");
			NumberContext ctx = new NumberContext();
			TextContext out = (TextContext)c.convert(ctx);
			assertEquals("abc", out.text);
		} catch (Exception e) {
			fail();
		}
	}
	
	public void testChain(){
		Processor p;
		try {
			p = factory.getProcessor("a chain");
			IntContext ctx = new IntContext();
			ctx.delay = 100;
			p.process(ctx);
			assertEquals(100 + 100 * 3, ctx.delay);
		} catch (Exception e) {
			fail();
		}
	}
	
	public void testBiBranch(){
		Processor p;
		try {
			p = factory.getProcessor("a bibranch");
			IntContext ctx = new IntContext();
			
			// valid branch: delay > 200
			ctx.delay = 223;
			p.process(ctx);
			assertEquals(223 + 100, ctx.delay);

			// invalid branch: delay <= 200
			ctx.delay = 123;
			p.process(ctx);
			assertEquals(123 - 100, ctx.delay);
		} catch (Exception e) {
			fail();
		}
	}
	
	public void testBranch(){
		Processor p;
		try {
			p = factory.getProcessor("a branch");
			TextContext ctx = new TextContext();
			
			// branch "key1"
			ctx.text = "key1";
			ctx.delay = 123;
			p.process(ctx);
			assertEquals(123 + 100, ctx.delay);

			ctx.text = "key2";
			ctx.delay = 123;
			p.process(ctx);
			assertEquals(123 - 100, ctx.delay);
			
			ctx.text = "key3";
			ctx.delay = 123;
			p.process(ctx);
			assertEquals("key3" + "abc", ctx.text);
			
			// Default key is "key1"
			ctx.text = "key4";
			ctx.delay = 123;
			p.process(ctx);
			assertEquals(123 + 100, ctx.delay);
		} catch (Exception e) {
			fail();
		}
	}
	
	public void testWhileLoop(){
		Processor p;
		try {
			p = factory.getProcessor("while loop");
			IntContext ctx = new IntContext();
			
			// while (delay < 200)
			ctx.delay = -123;
			p.process(ctx);
			assertEquals(-123 + 100 * 4, ctx.delay);
		} catch (Exception e) {
			fail();
		}
	}
	
	public void testDoWhileLoop(){
		Processor p;
		try {
			p = factory.getProcessor("do-while loop");
			IntContext ctx = new IntContext();
			
			// do while (delay > 200)
			ctx.delay = 123 + 300;
			p.process(ctx);
			assertEquals(123, ctx.delay);
		} catch (Exception e) {
			fail();
		}
	}
	
	public void testDecorator(){
		Processor p;
		try {
			p = factory.getProcessor("a decorator");
			TextContext ctx = new TextContext();
			ctx.text = "text";
			ctx.delay = 123;
			p.process(ctx);
			assertEquals(123 + 100, ctx.delay);
			assertEquals("text+before+end", ctx.text);
		} catch (Exception e) {
			fail();
		}
	}
	
	public void testAdapter(){
		Processor p;
		try {
			p = factory.getProcessor("an adapter");
			TextContext ctx = new TextContext();
			ctx.delay = 456;
			p.process(ctx);
			assertEquals(456, ctx.delay);
		} catch (Exception e) {
			fail();
		}
	}

	public void testProperty(){
		Processor p;
		try {
			p = factory.getProcessor("property processor");
			TextContext ctx = new TextContext();
			ctx.text = "";
			p.process(ctx);
			assertEquals("abc123", ctx.text);
		} catch (Exception e) {
			fail();
		}
	}

	public void testProcessorMixedWithConverter(){
		Processor p;
		try {
			p = factory.getProcessor("processor mixed with converter");
			TextContext ctx = new TextContext();
			ctx.delay = 123;
			p.process(ctx);
			assertEquals(123 + 100, ctx.delay);
		} catch (Exception e) {
			fail();
		}
	}
	
	public void testConverterMixedWithProcessor(){
		Converter c;
		try {
			c = factory.getConverter("converter mixed with processor");
			TextContext ctx = new TextContext();
			ctx.delay = 123;
			ctx.text = "";
			NumberContext out = (NumberContext)c.convert(ctx);
			assertEquals(123d, out.number);
			assertEquals(123 + 100, out.delay);
		} catch (Exception e) {
			fail();
		}
	}
	
	public void testProcessorReference(){
		Processor p;
		try {
			p = factory.getProcessor("processor reference");
			IntContext ctx = new IntContext();
			ctx.delay = 100;
			p.process(ctx);
			assertEquals(100 + 100 * 3, ctx.delay);
		} catch (Exception e) {
			fail();
		}
	}
		
	public void testDefaultDecorator(){
		Processor p;
		try {
			p = factory.getProcessor("default decorator");
			IntContext ctx = new IntContext();
			p.process(ctx);
		} catch (Exception e) {
			fail();
		}
	}

	public void testDefaultAdapter(){
		Converter c;
		try {
			c = factory.getConverter("default adapter");
			IntContext ctx = new IntContext();
			c.convert(ctx);
		} catch (Exception e) {
			fail();
		}
	}
}
