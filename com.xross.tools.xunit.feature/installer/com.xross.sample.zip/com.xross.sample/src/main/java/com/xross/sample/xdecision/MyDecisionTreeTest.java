package com.xross.sample.xdecision;

import junit.framework.TestCase;

import com.xross.tools.xdecision.DecisionTree;
import com.xross.tools.xdecision.utils.DecisionTreeFactory;

public class MyDecisionTreeTest extends TestCase {
	public void testGetDecision(){
		DecisionTree<String> tree = new DecisionTreeFactory().createFromXML("src/main/resources/my_tree.xdecision");
		
		//Verify tree
		Object[] test;
		
		test = new Object[11];
		test[1] = "above 18";
		assertEquals(test, "short", tree.get(test));
		test = new Object[11];
		test[1] = "above 18";
		test[3] = "above 100k";
		assertEquals(test, "happy", tree.get(test));
		test = new Object[11];
		test[1] = "above 18";
		test[3] = "below 100k";
		assertEquals(test, "reasonable---", tree.get(test));
		test = new Object[11];
		test[1] = "above 18";
		test[3] = "below 100k";
		test[4] = "10 to 60kg";
		assertEquals(test, "nice", tree.get(test));
		test = new Object[11];
		test[1] = "under 18";
		assertEquals(test, "decision9", tree.get(test));
		test = new Object[11];
		test[1] = "under 18";
		test[2] = "male";
		assertEquals(test, "decision9", tree.get(test));
		test = new Object[11];
		test[1] = "under 18";
		test[2] = "famale";
		assertEquals(test, "nice", tree.get(test));
		test = new Object[11];
		test[1] = "above 18";
		test[3] = "above 100k";
		test[2] = "famale";
		assertEquals(test, "reasonable---", tree.get(test));
		test = new Object[11];
		test[1] = "above 18";
		test[3] = "above 100k";
		test[2] = "male";
		assertEquals(test, "nice", tree.get(test));
		test = new Object[11];
		test[1] = "above 18";
		test[3] = "above 100k";
		test[2] = "famale";
		test[4] = "10 to 60kg";
		assertEquals(test, "sad", tree.get(test));

	}
	
	private void assertEquals(Object[] test, String expected, String actual){
		StringBuffer valueBuf = new StringBuffer();
		for(int i = 0; i < test.length; i++)
			if(test[i] == null)
				valueBuf.append("[]");
			else
				valueBuf.append("[" + test[i] + "]");
		
		assertEquals(expected, actual);
	}
}
