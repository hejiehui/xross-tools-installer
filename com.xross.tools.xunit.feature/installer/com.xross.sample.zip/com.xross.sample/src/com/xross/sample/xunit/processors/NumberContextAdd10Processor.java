package com.xross.sample.xunit.processors;

import com.xross.sample.xunit.contexts.NumberContext;
import com.xross.tools.xunit.Context;
import com.xross.tools.xunit.Processor;

public class NumberContextAdd10Processor implements Processor {

	@Override
	public void process(Context ctx) {
		((NumberContext)ctx).number += 10;
	}

}
