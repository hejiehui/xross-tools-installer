package com.xross.sample.xunit.contexts;


public class NumberContext extends IntContext {
	public double number;
}
