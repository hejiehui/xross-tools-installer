package com.xross.sample.xunit.processors;

import com.xross.sample.xunit.contexts.TextContext;
import com.xross.tools.xunit.Context;
import com.xross.tools.xunit.Processor;
import com.xross.tools.xunit.UnitConfigure;
import com.xross.tools.xunit.UnitConfigureAware;

public class PopulatePropertyProcessor implements Processor, UnitConfigureAware{
	private UnitConfigure configure;
	@Override
	public void process(Context ctx) {
		TextContext textCtx = (TextContext)ctx;
		String value = configure.getValue("key");
		textCtx.text += value;
		value = configure.getValue("test", "key");
		textCtx.text += value;
	}

	@Override
	public void setConfigure(UnitConfigure configure) {
		this.configure = configure;
	}

}
