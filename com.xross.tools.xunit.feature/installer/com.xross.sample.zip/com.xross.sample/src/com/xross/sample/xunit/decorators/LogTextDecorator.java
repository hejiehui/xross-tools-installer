package com.xross.sample.xunit.decorators;

import com.xross.sample.xunit.contexts.TextContext;
import com.xross.tools.xunit.Context;
import com.xross.tools.xunit.impl.DecoratorAdapter;

public class LogTextDecorator extends DecoratorAdapter {
	private long start;

	public void before(Context ctx) {
		TextContext tctx = (TextContext)ctx;
		tctx.text += "+before";
	}

	@Override
	public void after(Context ctx) {
		TextContext tctx = (TextContext)ctx;
		tctx.text += "+end";
	}

}
