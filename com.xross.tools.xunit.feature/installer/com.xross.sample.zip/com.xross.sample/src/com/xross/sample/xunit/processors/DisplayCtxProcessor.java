package com.xross.sample.xunit.processors;

import com.xross.sample.xunit.contexts.IntContext;
import com.xross.sample.xunit.contexts.NumberContext;
import com.xross.sample.xunit.contexts.TextContext;
import com.xross.tools.xunit.Context;
import com.xross.tools.xunit.Processor;

public class DisplayCtxProcessor implements Processor{

	@Override
	public void process(Context ctx) {
		if(ctx instanceof IntContext)
			System.out.println("Delay: " + ((IntContext)ctx).delay);
		if(ctx instanceof NumberContext)
			System.out.println("Number: " + ((NumberContext)ctx).number);
		if(ctx instanceof TextContext)
			System.out.println("Text: " + ((TextContext)ctx).text);
	}

}
