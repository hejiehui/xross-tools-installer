package com.xross.sample.xunit.processors;

import com.xross.sample.xunit.contexts.TextContext;
import com.xross.tools.xunit.Context;
import com.xross.tools.xunit.Processor;

public class TextContextAddABCProcessor implements Processor {

	@Override
	public void process(Context ctx) {
		((TextContext)ctx).text += "abc";
	}

}
