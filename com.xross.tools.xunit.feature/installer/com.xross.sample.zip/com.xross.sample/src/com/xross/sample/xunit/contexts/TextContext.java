package com.xross.sample.xunit.contexts;


public class TextContext extends IntContext {
	public String text;
}
