package com.xross.sample.xunit.converters;

import com.xross.sample.xunit.contexts.NumberContext;
import com.xross.sample.xunit.contexts.TextContext;
import com.xross.tools.xunit.Context;
import com.xross.tools.xunit.Converter;

public class Number2TextContextConverter implements Converter{

	@Override
	public Context convert(Context inputCtx) {
		NumberContext in = (NumberContext)inputCtx;
		TextContext out = new TextContext();
		
		out.delay = in.delay;
		out.text = "abc";
		
		return out;
	}

}
