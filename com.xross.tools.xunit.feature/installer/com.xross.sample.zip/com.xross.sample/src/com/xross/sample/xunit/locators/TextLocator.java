package com.xross.sample.xunit.locators;

import com.xross.sample.xunit.contexts.TextContext;
import com.xross.tools.xunit.Context;
import com.xross.tools.xunit.Locator;

public class TextLocator implements Locator {
	private String defaultKey;
	@Override
	public String locate(Context ctx) {
		return ((TextContext)ctx).text;
	}

	@Override
	public void setDefaultKey(String key) {
		defaultKey = key;
	}

	@Override
	public String getDefaultKey() {
		return defaultKey;
	}
}
